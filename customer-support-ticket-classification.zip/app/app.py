"""Flask application factory and JSON API."""
from __future__ import annotations

from pathlib import Path
from flask import Flask, jsonify, render_template, request

from app.predictor import TicketPredictor

ROOT = Path(__file__).resolve().parents[1]
MAX_CHARS = 5000


def create_app(config: dict | None = None) -> Flask:
    app = Flask(__name__)
    app.config.update(config or {})
    predictor = app.config.get("PREDICTOR") or TicketPredictor(ROOT / "models" / "ticket_classifier.joblib")

    @app.get("/")
    def index():
        return render_template("index.html")

    @app.get("/health")
    def health():
        return jsonify(status="ok")

    @app.post("/api/predict")
    def predict():
        if not request.is_json:
            return jsonify(error="Request must use application/json."), 415
        payload = request.get_json(silent=True)
        if not isinstance(payload, dict):
            return jsonify(error="Invalid JSON object."), 400
        allowed = {"subject", "description", "priority", "channel"}
        unknown = set(payload) - allowed
        if unknown:
            return jsonify(error=f"Unexpected fields: {', '.join(sorted(unknown))}"), 400
        subject = payload.get("subject", "")
        description = payload.get("description", "")
        if not isinstance(subject, str) or not isinstance(description, str):
            return jsonify(error="Subject and description must be strings."), 400
        if not subject.strip() and not description.strip():
            return jsonify(error="Enter a subject or description."), 400
        if len(subject) + len(description) > MAX_CHARS:
            return jsonify(error=f"Ticket text cannot exceed {MAX_CHARS} characters."), 413
        return jsonify(predictor.predict(subject, description))

    return app
