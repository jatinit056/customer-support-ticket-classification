"""Thread-safe model loading and prediction service."""
from __future__ import annotations

from pathlib import Path
import joblib
import numpy as np

from src.features import combine_text


class TicketPredictor:
    def __init__(self, model_path: Path):
        if not model_path.exists():
            raise FileNotFoundError(f"Model not found: {model_path}. Run python -m src.train")
        self.model = joblib.load(model_path)

    def predict(self, subject: str, description: str) -> dict:
        text = combine_text(subject, description)
        prediction = str(self.model.predict([text])[0])
        result = {"prediction": prediction}
        if hasattr(self.model, "predict_proba"):
            probabilities = self.model.predict_proba([text])[0]
            order = np.argsort(probabilities)[::-1][:3]
            result["confidence"] = float(probabilities[order[0]])
            result["alternatives"] = [{"category": str(self.model.classes_[idx]), "confidence": float(probabilities[idx])} for idx in order[1:]]
        return result
