from pathlib import Path
from app.predictor import TicketPredictor


def test_model_loads_and_predicts():
    predictor = TicketPredictor(Path("models/ticket_classifier.joblib"))
    result = predictor.predict("Password reset failed", "My account is locked and I cannot login")
    assert result["prediction"]
    if "confidence" in result:
        assert 0 <= result["confidence"] <= 1
