from app import create_app


def client():
    return create_app({"TESTING": True}).test_client()


def test_health():
    assert client().get("/health").get_json() == {"status": "ok"}


def test_home():
    assert client().get("/").status_code == 200


def test_prediction_success():
    response = client().post("/api/predict", json={"subject": "Card charged twice", "description": "Duplicate payment on my invoice"})
    assert response.status_code == 200
    assert response.get_json()["prediction"]


def test_blank_and_invalid_requests():
    assert client().post("/api/predict", json={"subject": "", "description": " "}).status_code == 400
    assert client().post("/api/predict", data="oops", content_type="text/plain").status_code == 415
    assert client().post("/api/predict", json={"subject": "x", "description": "y", "secret": 1}).status_code == 400
