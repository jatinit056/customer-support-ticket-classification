from src.data_processing import normalize_text
from src.features import combine_text


def test_normalize_text_handles_null_and_whitespace():
    assert normalize_text("  hello\n world ") == "hello world"
    assert normalize_text(None) == ""


def test_combine_text():
    assert combine_text(" Login ", " cannot  enter ") == "Login cannot enter"
