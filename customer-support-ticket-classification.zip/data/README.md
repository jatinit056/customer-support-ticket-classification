# Dataset

The checked-in `raw/synthetic_support_tickets.csv` is a reproducible, template-generated development fallback. It contains no real customers and must not be described as real-world data.

The preferred public dataset is Suraj520's **Customer Support Ticket Dataset** on Kaggle: https://www.kaggle.com/datasets/suraj520/customer-support-ticket-dataset. Kaggle labels it **CC0: Public Domain** and documents 8,469 rows and 17 columns, including ticket type, subject, description, priority, channel, status, resolution time, and satisfaction.

To substitute the real dataset, download `customer_support_tickets.csv`, place it in `data/raw/`, and map `Ticket Subject`, `Ticket Description`, and `Ticket Type` to `subject`, `description`, and `category`. Do not use resolution text as an input feature because it is created after triage and would leak future information.
