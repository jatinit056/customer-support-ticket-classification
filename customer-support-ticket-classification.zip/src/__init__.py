"""Training and analysis package."""
