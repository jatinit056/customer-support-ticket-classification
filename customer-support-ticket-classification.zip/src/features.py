"""Feature helpers."""
from src.data_processing import normalize_text


def combine_text(subject: object, description: object) -> str:
    return normalize_text(f"{normalize_text(subject)} {normalize_text(description)}")
