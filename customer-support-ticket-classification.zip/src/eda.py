"""Reusable exploratory summary helpers."""
import pandas as pd


def summarize(frame: pd.DataFrame) -> dict:
    return {"shape": list(frame.shape), "duplicates": int(frame.duplicated().sum()), "missing": frame.isna().sum().astype(int).to_dict(), "categories": frame["category"].value_counts().to_dict()}
