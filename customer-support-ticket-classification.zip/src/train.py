"""Train, compare, evaluate, explain, and persist ticket classifiers."""
from __future__ import annotations

import json
from pathlib import Path

import joblib
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import ConfusionMatrixDisplay, accuracy_score, classification_report, precision_recall_fscore_support
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
from sklearn.svm import LinearSVC

from src.data_processing import generate_synthetic_dataset, load_and_clean

ROOT = Path(__file__).resolve().parents[1]


def pipeline(model: object) -> Pipeline:
    return Pipeline([("tfidf", TfidfVectorizer(lowercase=True, stop_words="english", ngram_range=(1, 2), min_df=2, max_df=0.98, max_features=12000)), ("classifier", model)])


def _metrics(y_true, y_pred) -> dict:
    p_macro, r_macro, f_macro, _ = precision_recall_fscore_support(y_true, y_pred, average="macro", zero_division=0)
    p_weight, r_weight, f_weight, _ = precision_recall_fscore_support(y_true, y_pred, average="weighted", zero_division=0)
    return {"accuracy": accuracy_score(y_true, y_pred), "precision_macro": p_macro, "recall_macro": r_macro, "f1_macro": f_macro, "precision_weighted": p_weight, "recall_weighted": r_weight, "f1_weighted": f_weight}


def train() -> dict:
    data_path = ROOT / "data" / "raw" / "synthetic_support_tickets.csv"
    if not data_path.exists():
        generate_synthetic_dataset(data_path)
    frame, cleaning = load_and_clean(data_path)
    train_x, test_x, train_y, test_y = train_test_split(frame["text"], frame["category"], test_size=0.2, random_state=42, stratify=frame["category"])
    candidates = {
        "Logistic Regression": LogisticRegression(max_iter=1200, class_weight="balanced", random_state=42),
        "LinearSVC": LinearSVC(class_weight="balanced", random_state=42),
        "Multinomial Naive Bayes": MultinomialNB(alpha=0.3),
    }
    results, trained = {}, {}
    for name, estimator in candidates.items():
        model = pipeline(estimator).fit(train_x, train_y)
        predicted = model.predict(test_x)
        results[name] = _metrics(test_y, predicted)
        results[name]["classification_report"] = classification_report(test_y, predicted, output_dict=True, zero_division=0)
        trained[name] = model
    best_name = max(results, key=lambda name: results[name]["f1_macro"])
    best = trained[best_name]
    final_predictions = best.predict(test_x)
    (ROOT / "models").mkdir(exist_ok=True)
    (ROOT / "reports" / "figures").mkdir(parents=True, exist_ok=True)
    joblib.dump(best, ROOT / "models" / "ticket_classifier.joblib")
    ConfusionMatrixDisplay.from_predictions(test_y, final_predictions, xticks_rotation=35, cmap="Blues", colorbar=False)
    plt.tight_layout(); plt.savefig(ROOT / "reports" / "figures" / "confusion_matrix.png", dpi=160); plt.close()
    frame["category"].value_counts().sort_values().plot.barh(color="#5b5bd6")
    plt.title("Ticket category distribution"); plt.xlabel("Tickets"); plt.tight_layout(); plt.savefig(ROOT / "reports" / "figures" / "category_distribution.png", dpi=160); plt.close()
    frame["text"].str.len().plot.hist(bins=25, color="#24a67a")
    plt.title("Ticket text length"); plt.xlabel("Characters"); plt.tight_layout(); plt.savefig(ROOT / "reports" / "figures" / "text_length_distribution.png", dpi=160); plt.close()
    metadata = {"selected_model": best_name, "selection_metric": "f1_macro", "classes": list(best.classes_), "training_rows": len(train_x), "test_rows": len(test_x), "total_rows": len(frame), "dataset": "Synthetic development fallback", "dataset_is_synthetic": True, "cleaning": cleaning}
    (ROOT / "models" / "model_metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    payload = {"selected_model": best_name, "dataset": metadata["dataset"], "records": len(frame), "test_records": len(test_x), "models": results}
    (ROOT / "reports" / "model_metrics.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
    frame.drop(columns="text").to_csv(ROOT / "data" / "processed" / "tickets_clean.csv", index=False)
    return payload


if __name__ == "__main__":
    print(json.dumps(train(), indent=2))
