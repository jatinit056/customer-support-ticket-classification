"""Dataset loading, validation, and reproducible fallback generation."""
from __future__ import annotations

import random
import re
from datetime import datetime, timedelta
from pathlib import Path

import pandas as pd

CATEGORIES = {
    "Technical Issue": (["crash", "error", "screen", "update", "device"], ["keeps failing", "will not start", "shows an error", "stopped working"]),
    "Billing Inquiry": (["invoice", "charged", "payment", "billing", "card"], ["amount is incorrect", "was charged twice", "payment was declined", "need a receipt"]),
    "Account Access": (["login", "password", "account", "verification", "locked"], ["cannot sign in", "reset link expired", "account is locked", "code never arrived"]),
    "Refund Request": (["refund", "return", "cancel", "money", "purchase"], ["want my money back", "return was approved", "cancel this order", "refund is missing"]),
    "Product Inquiry": (["feature", "compatible", "plan", "product", "upgrade"], ["need more information", "is this supported", "which plan includes it", "want to compare options"]),
    "Shipping Issue": (["delivery", "tracking", "package", "shipment", "courier"], ["has not arrived", "tracking is frozen", "went to wrong address", "package was damaged"]),
    "General Support": (["help", "question", "support", "contact", "guidance"], ["need some assistance", "have a general question", "please contact me", "where can I find help"]),
}


def normalize_text(value: object) -> str:
    text = "" if pd.isna(value) else str(value)
    return re.sub(r"\s+", " ", text).strip()


def generate_synthetic_dataset(path: Path, rows_per_class: int = 300, seed: int = 42) -> pd.DataFrame:
    """Create a labeled development dataset; it is never represented as real data."""
    rng = random.Random(seed)
    records = []
    start = datetime(2024, 1, 1)
    priorities = ["Low", "Medium", "High", "Critical"]
    channels = ["Email", "Chat", "Phone", "Web"]
    statuses = ["Open", "Pending", "Resolved", "Closed"]
    for category, (terms, issues) in CATEGORIES.items():
        for idx in range(rows_per_class):
            term, issue = rng.choice(terms), rng.choice(issues)
            created = start + timedelta(hours=rng.randint(0, 8000))
            resolution = rng.randint(1, 120)
            records.append({
                "ticket_id": f"SYN-{len(records)+1:05d}",
                "subject": f"{term.title()} {rng.choice(['problem', 'request', 'question', 'help'])}",
                "description": f"Hello support, my {term} {issue}. Please help me resolve this {rng.choice(['today', 'soon', 'when possible'])}.",
                "category": category,
                "priority": rng.choice(priorities),
                "status": rng.choice(statuses),
                "channel": rng.choice(channels),
                "created_at": created.isoformat(),
                "resolution_time_hours": resolution,
                "customer_satisfaction": rng.randint(1, 5),
                "is_synthetic": True,
            })
    rng.shuffle(records)
    frame = pd.DataFrame(records)
    path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(path, index=False)
    return frame


def load_and_clean(path: Path) -> tuple[pd.DataFrame, dict[str, int]]:
    frame = pd.read_csv(path)
    required = {"subject", "description", "category"}
    missing = required - set(frame.columns)
    if missing:
        raise ValueError(f"Dataset missing required columns: {sorted(missing)}")
    before = len(frame)
    frame = frame.drop_duplicates().copy()
    for column in required:
        frame[column] = frame[column].map(normalize_text)
    frame = frame[(frame["category"] != "") & ((frame["subject"] != "") | (frame["description"] != ""))]
    frame["text"] = (frame["subject"] + " " + frame["description"]).map(normalize_text)
    return frame.reset_index(drop=True), {"rows_before": before, "rows_after": len(frame), "removed": before - len(frame)}
